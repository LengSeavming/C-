﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Manage_Inventoty.Classes
{
    internal class oder_item
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public int QTY { get; set; }
        public decimal Price { get; set; }

        
    }
}
